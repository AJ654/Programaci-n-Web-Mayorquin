<?php
class Automovil
{
    public $tipo;
    public $modelo;
    public $año;
    public $problemaDesc;
    public $fechaIngreso;
    public $fechaSalida = 0;

    public function __construct($_tipo, $_modelo  , $_año, $_problemaDesc, $_fechaIngreso)
    {
        $this->tipo = $_tipo;
        $this->modelo = $_modelo;
        $this->año = $_año;
        $this->problemaDesc = $_problemaDesc;
        $this->fechaIngreso = $_fechaIngreso;
    }

    public function imprimir()
    {
        echo "<br>--------------------------------------------<br>";
        echo "<h1>".$this->modelo."</h1>";
        echo "<i>".$this->año."</i><br>";
        echo "<h3>Datos:</h3>";
        echo "[<b>".$this->tipo."</b>]<br>Fecha de Ingreso: [<b>".$this->fechaIngreso."</b>]";
        echo "<br>Problema: ".$this->problemaDesc."<br>";
        if ($this->fechaSalida == 0) echo "<b>El vehiculo sigue en el taller.</b>";
        else echo "Fecha de Salida: [<b>".$this->fechaSalida."</b>]";
        echo "<br>--------------------------------------------";
    }
}

$Auto1 = new Automovil ("Automovil", "Ford Mustang GT", "2020", "Cuesta mucho trabajo cambiar de velocidad.", "17/09/2024");

$Auto2 = new Automovil("", "", "", "", "");
$Auto2->tipo = "Automovil";
$Auto2->modelo = "Chevrolet Camaro";
$Auto2->año = "2018";
$Auto2->problemaDesc = "Al superar la velocidad de 80 km/h el motor se apaga.";
$Auto2->fechaIngreso = "12/07/2024";
$Auto2->fechaSalida = "18/09/2024";

$Auto3 = new Automovil ("Motocicleta", "Yamaha MT-07", "2022", "Se necesitan bastantes intentos para encenderla.", "03/06/2024");
$Auto3->fechaSalida = "25/08/2024";

$Auto1->imprimir();
$Auto2->imprimir();
$Auto3->imprimir();

?>